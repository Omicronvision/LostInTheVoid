#!/bin/bash
export CLASSPATH=`find ./lib -name "*.jar" | tr '\n' ':'`
export MAINCLASS=LostInTheVoid

java -cp ${CLASSPATH}:classes $MAINCLASS
