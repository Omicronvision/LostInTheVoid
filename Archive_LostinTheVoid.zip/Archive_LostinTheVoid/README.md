Lost in the Void
===========

Développé par Jérôme Sauvé et Dawid Banas
Contacts: jerome.sauve.etu@univ-lille.fr
          dawid.banas.etu@univ-lille.fr

# Présentation de Lost in the Void

Lociciel proposant aux utilisateurs de répondre dans un contexte immersif à des questions de Physique, Chimie ou électricité. L'utilisateur contrôle un vaisseau et doit veiller à survivre un certain nombre de tours. Le jeu s'arrête si l'utilisateur arrive au bout du jeu, ou si une des ressources du vaisseau tombe à zéro. L'utilisateur peut régler au lancement du jeu ses préférences de difficulté ou d'affichage des cadres contenant les textes affichés.
Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de Lost in the Void

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu
