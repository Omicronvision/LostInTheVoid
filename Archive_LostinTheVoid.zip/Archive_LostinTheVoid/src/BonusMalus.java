class BonusMalus{
    String[] casPossibles;
    int[][] impactMax; //tableau de taille int[3][length(casPossibles)], les lignes selon la ressource concernée pour des variations constantes
    int[][] perteMax;  //tableau de taille int[3][length(casPossibles)], les lignes selon la ressource concernée pour une variation de la perte par heure des ressources
    int[][] varStockage; //tableau de taille int[3][length(casPossibles)], les lignes selon la ressource concernée pour une variation de la valeur Max des ressources
    String[] typeCas;
}