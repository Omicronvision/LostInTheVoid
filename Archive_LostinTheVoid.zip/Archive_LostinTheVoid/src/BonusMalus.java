class BonusMalus{
    String[] casPossibles;
    int[][] impactMax; //tableau de taille int[3][length(casPossibles)], les lignes selon la ressource concernée 
    int[][] perteMax;  //tableau de taille int[3][length(casPossibles)], les lignes selon la ressource concernée 
}