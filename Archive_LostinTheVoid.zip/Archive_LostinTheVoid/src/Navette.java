class Navette{
    String nom;
    int logH;
    int nivOxy;
    int nivElec;
    int nivTemp;
    int nivTempMAX;
    int nivElecMAX;
    int nivOxyMAX;
    int perteElec;
    int perteOxy;
    int perteTemp;
    int fatigue;
}