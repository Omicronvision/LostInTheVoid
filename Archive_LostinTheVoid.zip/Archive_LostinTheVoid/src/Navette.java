class Navette{
    String nom;
    int logH;
    int[] nivOxygene;      //par rapport à l'alpha, on rédifinit les ressources comme tel :
    int[] nivElectricite;  // ressource = {nivRessource,nivRessourceMAX,perteRessource};
    int[] nivTemperature;  // on avait la possibilité de définir un seul int[][] mais ça aurait gâché la compréhension du code
    int fatigue;
}