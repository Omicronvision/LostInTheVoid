import extensions.CSVFile;

class LostInTheVoid extends Program{
    final String CLEAR = "\033[2J";
    // COULEURS UTILES
    final String COLOR_CYAN = "\u001B[36m";
    final String COLOR_ORANGE = "\u001B[38;2;255;165;0m";
    final String COLOR_RED = "\u001B[31m";
    final String COLOR_DARK_RED = "\u001B[38;2;178;34;34m";
    final String COLOR_YELLOW = "\u001B[33m";
    final String COLOR_BLUE = "\u001B[34m";
    final String COLOR_LIME = "\u001B[38;2;0;255;0m";
    final String COLOR_GOLD = "\u001B[38;2;255;215;0m";

    // COULEURS DE FOND
    final String COLOR_RED_BG = "\u001B[48;2;255;0;0m";
    final String COLOR_GREEN_BG = "\u001B[42m";
    // STYLES DE TEXTE
    final String STYLE_BOLD = "\033[0;1m";
    final String STYLE_UNDERLINE = "\u001B[4m";
    final String STYLE_ITALIC = "\u001B[3m";

    enum Scene{
        MENU, PARAMETRES, INTRODUCTION, JEU;
    }

    boolean exec = true;
    Scene sceneActuelle = Scene.MENU;
    int oxygene=80;
    int elec=65;
    int temperature=40;
    int tailleEcran=70;
    int deg=6;

    Quiz quizElec;
    Quiz quizOxyg;
    Quiz quizTemp;
    Quiz quizGen;
    BonusMalus bonus;
    BonusMalus malus;
    /////////////////////////////////////////////
    //////////////////Definition/////////////////
    /////////////////////////////////////////////
    void initQuestions(){
        quizElec = newQuiz("./ressources/questionsElec.csv");
        quizOxyg = newQuiz("./ressources/questionsOxyg.csv");
        quizTemp = newQuiz("./ressources/questionsTemp.csv");
        quizGen  = newQuiz("./ressources/questionsGen.csv");
    }
    
    
    Quiz newQuiz(String nomFichier){
        CSVFile fichier = loadCSV(nomFichier);
        Quiz tempQuiz = new Quiz();
        tempQuiz.quiz = new String[rowCount(fichier)][columnCount(fichier)];
        tempQuiz.questionPrecedente=-1;
        for(int i = 0; i < rowCount(fichier); i++){
            for(int j = 0; j < columnCount(fichier); j++){
                tempQuiz.quiz[i][j] = getCell(fichier, i, j);
            }
        }
        return tempQuiz;
    }
    void initBonusMalus(){
        bonus=initBM("./ressources/Bonus.csv");
        malus=initBM("./ressources/Malus.csv");
    }
    
    BonusMalus initBM(String nomFichier){
        CSVFile fichier= loadCSV(nomFichier);
        BonusMalus bm=new BonusMalus();
        int nlignes=rowCount(fichier);
        bm.casPossibles=new String[nlignes];
        bm.impactMax=new int[nlignes-1][3];
        bm.perteMax=new int[nlignes-1][3];
        for(int l=1;l<nlignes-1;l=l+1){
            bm.casPossibles[l-1]=getCell(fichier,l,0);
            bm.impactMax[l-1][0]=deChaineAEntier(getCell(fichier,l,1));
            bm.impactMax[l-1][1]=deChaineAEntier(getCell(fichier,l,2));
            bm.impactMax[l-1][2]=deChaineAEntier(getCell(fichier,l,3));
            bm.perteMax[l-1][0]=deChaineAEntier(getCell(fichier,l,4));
            bm.perteMax[l-1][1]=deChaineAEntier(getCell(fichier,l,5));
            bm.perteMax[l-1][2]=deChaineAEntier(getCell(fichier,l,6));
        }
        return bm;
    }

    Param setParametres(){
        Param param= new Param();
        param.tailleEcran=tailleEcran;
        param.nivOxyInitial=oxygene;
        param.nivTempInitial=temperature;
        param.nivElecInitial=elec;
        param.degats=deg;
        param.duréeJeu=20;
        param.perteInit=2;
        param.difficulte=2;
        param.probaBonus=0.4;
        param.probaMalus=0.1;
        return param;
    }

    Param param=setParametres();//A chaque lancement de jeu il est chargé les paramètres en difficulté normale. 

    void setDifficulty(Param param){ //fonction dont on fait appel dans le menu paramètre pour régler la difficulté selon les options possibles, changeant le contenu du type Param chargé plus haut.
        print("Voulez vous changer de difficulté ? (Oui/Non) :");
        String confirm=readString();
        confirm=toLowerCase(confirm);
        if((equals(confirm,"oui"))||(equals(confirm,"o"))||(equals(confirm,"y"))){
            int difficultéChoisie=-1;
            print("Saisissez la difficulté : 1.Facile 2.Normal 3.Difficile\n Votre difficulté actuelle est sur "+param.difficulte+" : ");
            do{
                difficultéChoisie=readInt();
                if(difficultéChoisie==1){
                    param.difficulte=1;
                    param.degats=2;
                    param.duréeJeu=10;
                    param.probaBonus=0.5;
                    param.probaMalus=0;
                    println("Votre jeu est passé en mode FACILE");

                }else if(difficultéChoisie==2){
                    param.difficulte=2;
                    param.degats=5;
                    param.duréeJeu=20;
                    param.probaBonus=0.4;
                    param.probaMalus=0.1;
                    println("Votre jeu est passé en mode MOYEN");
                    
                }else if(difficultéChoisie==3){
                    param.difficulte=3;
                    param.degats=8;
                    param.duréeJeu=40;
                    param.probaBonus=0.25;
                    param.probaMalus=0.25;
                    println("Votre jeu est passé en mode DIFFICILE");
                }
                    
                    
            }while(!estChoixPossible(1,3,difficultéChoisie));

        }  
    }

    void setAffichage(Param param){ // fonction appelée dans le menu paramètre permettant de régler la taille des bulles 
        print("Choisissez la taille des bulles qui vous seront affichées : ");
        println("taille minimale de 50, ici exemples de grandeurs : ");
        créerLigne('-',50);println("50");
        créerLigne('-',70);println("70");
        créerLigne('-',90);println("90");
        print("Saisissez une taille adaptée à vos préférences :");
        int taille=readInt();
        while(taille<50){
            print("Trop petit, veuillez saisir une valeur plus grande : ");
            taille=readInt();
        }
        param.tailleEcran=taille;
    }
    
    Navette newNavette(Param param){
        Navette nav=new Navette();
        nav.nivOxy=param.nivOxyInitial;
        nav.nivElec=param.nivElecInitial;
        nav.nivTemp=param.nivTempInitial;
        nav.nivElecMAX=100;
        nav.nivOxyMAX=100;
        nav.nivTempMAX=100;
        nav.fatigue=0;
        nav.perteElec=param.degats;
        nav.perteOxy=param.degats;
        nav.perteTemp=param.degats;
        nav.logH=0;
        return nav;
    }
    

    int deChaineAEntier(String chaine){
        int puissance =1;
        int entier=0;
        for(int i=0; i<length(chaine);i=i+1){
            if((charAt(chaine,length(chaine)-i-1)>='0')&&(charAt(chaine,length(chaine)-i-1)<='9')){
                entier=entier+puissance*(int)(charAt(chaine,length(chaine)-i-1)-'0');
                puissance=puissance*10;
            }
        }
        if(charAt(chaine,0)=='-'){
            entier=entier*-1;
        }
        return entier;
    }
    
    boolean estChoixPossible(int minchoix, int maxchoix, int choix){
        boolean valide=true;
        if(!((choix>=minchoix)&&(choix<=maxchoix))){
            print("Option saisie invalide, veuillez réessayer : ");
            valide=false;
        }
        return valide;
    }
    /////////////////////////////////////////////
    ///////////////AFFICHAGE BULLES//////////////
    /////////////////////////////////////////////
    //Les bulles dans notre programme désigne les cadres dans les lesquels on insère un texte, donnant une certaine identitié visuelle à notre jeu, pouvant rappeler des écrans de poste de vaisseau

    void créerLigne(char c, int n){ //permet de créer les cadres supérieurs et inférieurs de nos bulles
        for( int i=0; i<n; i=i+1){
            print(c);
        }
        println();
    }

    int nombreLignes(String texte, Param param){ //permet de connaître la taille du tableau de String dans lequel notre texte sera conservé
        int n=0;
        int débutLigne=0;
        int finLigne=0;
        for(int i=0; i<length(texte); i=i+1){
            if(charAt(texte,i)=='\n'){    
                n=n+1;        
                débutLigne=i+1;
            }/*else if((charAt(texte,i)=='A')&&(i<length(texte)-5)&&(equals(substring(texte,i,i+4),"ANSI"))){


            }*/else if(i-débutLigne==param.tailleEcran-6){
                n=n+1;
                finLigne=idxRetour(texte,i);
                débutLigne=finLigne+1;
            }
        }
        return n;
    }
    
    int idxRetour(String txt, int pdepart){//permet de ne pas casser un mot en deux en passant une ligne
        int idr = pdepart;
        while(charAt(txt,idr)!=' '){
            idr=idr-1;
        }
        return idr;
    }
    
    String[] décompenLigne(String texte, Param param){ //décompose le texte en lignes de taille max définie et les conserve dans un tableau
        int nlignesmax=nombreLignes(texte,param);
        String[] decomp = new String[nlignesmax];
        int débutLigne=0;
        int idx=0;
        int i=0;
        int longueurANSI=length(ANSI_RESET);
        String ligne="";
        if(length(decomp)>0){
            while(i<length(texte)-1){
                
                if(charAt(texte,i)=='\n'){
                    ligne=substring(texte,débutLigne,i);
                    decomp[idx]=Remplissage(ligne,param,caracteresANSIPresents(ligne));
                    idx=idx+1;
                    débutLigne=i+2;
                    ligne="";
                }else if(i-débutLigne==param.tailleEcran-6){
                    ligne=substring(texte,débutLigne,idxRetour(texte,i));
                    decomp[idx]=Remplissage(ligne,param,caracteresANSIPresents(ligne));
                    idx=idx+1;
                    débutLigne=idxRetour(texte,i)+1;
                    ligne="";
                }
                i=i+1;

            }
            if(débutLigne<length(texte)){
                ligne=substring(texte,débutLigne,length(texte)-1);
                decomp[length(decomp)-1]=Remplissage(ligne,param,caracteresANSIPresents(ligne));  
            }
            
        }
        
        
        return decomp;
    }

    String Remplissage(String ligne, Param param,int longueurEnPlus){ //permet, si une chaine de caractère ne fait pas la taille maximale d'un ligne, de la remplir et d'ajouter les 
        String nouvligne=ligne;                                         // traits verticaux, qui sauf faute serot alignés pour pouvoir afficher un cadre parfaitement rectangulaire
        while(length(nouvligne)<param.tailleEcran+longueurEnPlus-6){    // le paramètre longueurEnPlus a été ajouté lorsque l'on a remarqué les décalages créés avec les caractères ANSI.
            nouvligne=nouvligne+" ";
        }
        nouvligne= "|  "+nouvligne+"  |\n";
        return nouvligne;

    }

    void afficherBulle(String texte, Param param, int suppTaille){ //affiche le cadre en faisant appel aux fonctions définies plus tôt.
        String[] decomp=décompenLigne(texte,param);
        int L=length(decomp);
        créerLigne('-',param.tailleEcran);
        print(Remplissage("",param,0));
        for(int i=0; i<L; i=i+1){
            print(decomp[i]);
        }
        print(Remplissage("",param,0));
        créerLigne('-',param.tailleEcran);

    }
    int caracteresANSIPresents(String ligne){ //les caractère ANSI ne prennent pas d'espace graphiquement mais ont une longueur non nulle, ce qui crée un décalage dans nos bulles 
        int cpt=0;                              //Cette fonction permet donc de détecter si une ligne fait usage de ces caractères et permet de connaître le décalage à apporter pour avoir un cadre parfait
        int taillesup=0;
        for(int i=0; i<length(ligne)-2;i=i+1){
            String lig= charAt(ligne,i)+" "+charAt(ligne,i+1)+" "+charAt(ligne,i+2);
            if(charAt(lig,length(lig)-1)=='m'){
                if(((charAt(lig,0)>='0')&&(charAt(lig,0)<='9'))&&((charAt(lig,2)>='0')&&(charAt(lig,2)<='9'))){
                    cpt++;

                }
            }
        }
        if(cpt>0){
            taillesup=cpt*9;
        }
        return taillesup;
    }
    /////////////////////////////////////////////
    /////////////AFFICHAGE INTERFACE/////////////
    /////////////////////////////////////////////

    void afficherNiveaux(Navette nav,Param param){ //affiche une bulle avec les variables importantes à la gestion d
        créerLigne('-',param.tailleEcran);
        print(Remplissage("    Oxygène :"+COLOR_BLUE+créerJauge(nav.nivOxy,nav.nivOxyMAX)+ANSI_RESET,param,2*length(ANSI_RESET)+1));
        print(Remplissage("    Energie :"+COLOR_YELLOW+créerJauge(nav.nivElec, nav.nivElecMAX)+ANSI_RESET,param,2*length(ANSI_RESET)+1));
        print(Remplissage("Température :"+COLOR_RED+créerJauge(nav.nivTemp, nav.nivTempMAX)+ANSI_RESET,param,2*length(ANSI_RESET)+1));
        print(Remplissage("    Fatigue : "+nav.fatigue+"%",param,0));
        /// Température : ◼◼◼◼◼◻◻◻◻◻ (100/200)
        créerLigne('-',param.tailleEcran);
        
    }

    String créerJauge(int val, int valmax){
        String jauge="";
        int valr=10*val/valmax;
        for(int i=0; i<valr; i=i+1){
            jauge=jauge+"◼";
        }
        while(length(jauge)<10){
            jauge=jauge+"◻";
        }
        jauge+="("+val+"/"+valmax+")";
        return jauge;
    }

    void afficherActions(Navette nav,Param param,boolean[][] event, BonusMalus B, BonusMalus M){
        //renommer les actions et en ajouter d'autres
        
            afficherBulle(nav.nom+"\n "+"Heure "+nav.logH+"\n Veuillez choisir l'action à mener :\n 1.Oxygène\n 2.Electrique\n 3.Chauffage\n 4.Consulter un manuel ou le scanner\n 0.Repos\n",param,0);
            int act;
            do{
                
                act=readInt();//#amélioration possible : faire un readString, comme ça on peut mettre l'option help pour mieux indiquer 
                if(VaisseauDetruit(nav)){
                    act=-10000;
                }
                if(act==1){
                    actionOxy(nav, param,B,M,event);
                }else if(act==2){
                    actionElec(nav, param,B,M,event);
                }else if(act==3){
                    actionChauff(nav, param,B,M,event);
                }else if(act==4){
                    actionGen(nav,param,event);
                }else if(act==0){
                    int tempsRepos;
                    do{
                        print("Combien d'heures voulez vous vous reposer ? (tapez 0 pour réafficher vos niveaux de ressources):");
                        tempsRepos=readInt();
                        repos(nav,event,B,M,tempsRepos,param);
                    }while(!estChoixPossible(0,param.duréeJeu,tempsRepos));
                    
                }else if(act==-10000){
                    sceneActuelle=Scene.MENU;
                    break;
                }
            }while(!estChoixPossible(0,3,act)||(act==-10000));
        
    }
    
    /////////////////////////////////////////////
    ///////////////Mécaniques Jeu////////////////
    /////////////////////////////////////////////
    boolean posQuiz(Quiz tabQuiz){
        boolean correct = false;
        //&&!estChoixPossible(0,length(tabQuiz.quiz,1),num)&&
        int num=tabQuiz.questionPrecedente;
        while(((num==tabQuiz.questionPrecedente))){
            num=(int)(random()*length(tabQuiz.quiz,1));
        }
        
        //stocke la questionif(equals(getCell(1),"QCM"))*/
        tabQuiz.questionPrecedente=num;
        String question = tabQuiz.quiz[num][1];
        if(equals(tabQuiz.quiz[num][0],"QCM")){
            int saisie;
            do{
                println(STYLE_UNDERLINE + COLOR_GOLD + "Question QCM");
                print(STYLE_BOLD + COLOR_CYAN + question + ANSI_RESET + "\n\n");

                //afficher les réponses
                println("1) "+ tabQuiz.quiz[num][2]);            
                println("2) " + tabQuiz.quiz[num][3]);
                println("3) " + tabQuiz.quiz[num][4]);
                println("4) " + tabQuiz.quiz[num][5]);
                println("\nChoisissez votre réponse (1,2,3 ou 4)");
                saisie = readInt();
            }while(!estChoixPossible(1,4,saisie));
            
            //on ajoute 1 pour le décalage dans le tableau des questions
            saisie += 1;
            if(equals(tabQuiz.quiz[num][6], tabQuiz.quiz[num][saisie])){
                correct = true;
            }        
        }else if(equals(tabQuiz.quiz[num][0], "QUE")){
            println(STYLE_UNDERLINE + COLOR_GOLD + "Question de saisie simple");
            print(STYLE_BOLD + COLOR_CYAN + question + ANSI_RESET + "\n\n");
            //précision si besoin pour la réponse demandée
            print(STYLE_ITALIC + tabQuiz.quiz[num][2] + "\n\n" + ANSI_RESET);
            String saisietexte = readString();
            if(equals(toLowerCase(saisietexte), toLowerCase(tabQuiz.quiz[num][3]))){
                correct = true;
            } else if(equals(toLowerCase(saisietexte), toLowerCase(tabQuiz.quiz[num][4]))){
                correct = true;
            } else if(equals(toLowerCase(saisietexte), toLowerCase(tabQuiz.quiz[num][5]))){
                correct = true;
            } else if(equals(toLowerCase(saisietexte), toLowerCase(tabQuiz.quiz[num][6]))){
                correct = true;
            }
        }
        return correct;
    }
    void actionElec(Navette nav, Param param,BonusMalus B, BonusMalus M,boolean[][]event){
           if(nav.fatigue+15<=100){
            boolean bonneRep=posQuiz(quizElec);
            if(bonneRep){//IF REUSSI
               nav.fatigue=nav.fatigue+15;
                println(COLOR_GREEN_BG + "Mission électrique accomplie, bien joué !" + ANSI_RESET);
                nav.nivElec+=15;
                  
            }else{//SI PAS REUSSI
                nav.fatigue+=5;
                println(COLOR_RED_BG + "Surcharge électrique ! Le système a cramé... La bonne réponse était : " + quizElec.quiz[quizElec.questionPrecedente][6] + ANSI_RESET);
            }
            verifNiveaux(nav);
        }else{
            println(COLOR_DARK_RED + "Désolé, vous êtes trop fatigué pour  faire cette action, Veuillez faire autre chose : " + ANSI_RESET);
        }
        
    }

    void actionOxy(Navette nav, Param param,BonusMalus B, BonusMalus M,boolean[][]event){
        if(nav.fatigue+15<=100){
            boolean bonneRep=posQuiz(quizOxyg);
            if(bonneRep){//IF REUSSI
               nav.fatigue=nav.fatigue+15;
                println(COLOR_GREEN_BG + "Mission réussie : l’Oxygène s’accumule dans les réserves !" + ANSI_RESET);
                nav.nivOxy+=15;
                  
            }else{//SI PAS REUSSI
                nav.fatigue+=5;
               println(COLOR_RED_BG + "Échec critique : pas de gain d’oxygène cette fois. La bonne réponse était : " + quizOxyg.quiz[quizOxyg.questionPrecedente][6] + ANSI_RESET);
            }
            verifNiveaux(nav);
        }else{
            println(COLOR_DARK_RED + "Désolé, vous êtes trop fatigué pour  faire cette action, Veuillez faire autre chose : " + ANSI_RESET);
        }
    }

    void actionChauff(Navette nav, Param param,BonusMalus B, BonusMalus M,boolean[][]event){
       if(nav.fatigue+15<=100){
            boolean bonneRep=posQuiz(quizTemp);
            if(bonneRep){//IF REUSSI
               nav.fatigue=nav.fatigue+15;
                println(COLOR_GREEN_BG + "Bravo, la température est stabilisée, ça chauffe !" + ANSI_RESET);
                nav.nivTemp+=15;
                  
            }else{//SI PAS REUSSI
                nav.fatigue+=5;
               println(COLOR_RED_BG + "Raté ! La température ne monte pas, on gèle ici ! La bonne réponse était : " + quizTemp.quiz[quizTemp.questionPrecedente][6] + ANSI_RESET);
            }
            verifNiveaux(nav); 
        }else{
            println(COLOR_DARK_RED + "Désolé, vous êtes trop fatigué pour  faire cette action, Veuillez faire autre chose : " + ANSI_RESET);
        }
    }
    void actionGen(Navette nav, Param param, boolean[][] event){
        if(nav.fatigue+5<=100){
            boolean bonneRep=posQuiz(quizGen);
            if(bonneRep){
                nav.fatigue+=5;
                int choixMatière;
                do{
                    afficherBulle("Veuillez choisir l'action que vous préférez :\n 1.Consulter les manuel d'aide aux électriciens.\n 2.Consulter le manuel d'aide d'usage de la ventilation.\n 3.Consulter le manuel d'entretien du chauffage.\n 4.lancer une analyse scanner des incidents possibles les 3 prochaines heures.\n ",param,0);
                    choixMatière=readInt();
                }while(!estChoixPossible(1,4,choixMatière));
                int repquiz;
                if(choixMatière==1){
                    println("Vous vous rendez dans la section Oxygène, vous lisez :");
                    repquiz=(int)(random()*length(quizOxyg.quiz,1));
                    println(quizOxyg.quiz[repquiz][1]);
                    println(quizOxyg.quiz[repquiz][length(quizOxyg.quiz,2)-1]);
                }else if(choixMatière==2){
                    println("Vous vous rendez dans la section Electricité, vous lisez :");
                    repquiz=(int)(random()*length(quizElec.quiz,1));
                    println(quizElec.quiz[repquiz][1]);
                    println(quizElec.quiz[repquiz][length(quizElec.quiz,2)-1]);
                }else if(choixMatière==3){
                    println("Vous vous rendez dans la section Température, vous lisez :");
                    repquiz=(int)(random()*length(quizTemp.quiz,1));
                    println(quizTemp.quiz[repquiz][1]);
                    println(quizTemp.quiz[repquiz][length(quizTemp.quiz,2)-1]);
                }else if(choixMatière==4){
                    println("Vous lancez votre scanner :");
                    int cptMalusEvite=0;
                    for(int i=1; i<=3; i++){
                        if((nav.logH+i<param.duréeJeu)&&(event[1][nav.logH+i]==true)){
                            event[1][nav.logH+i]=false;
                            cptMalusEvite++;
                        }
                        println("Grâce à votre prudence, vous avez su éviter "+cptMalusEvite+" incidents !");
                    }
                    if(cptMalusEvite==0){
                        println("Vous n'avez rien détecté à l'horizon");
                    }
                }
            }else{
                nav.fatigue+=2;
                println("Vous vous êtes endormi sur vore livre avant de trouver quelque chose qui vous intéressait");
                String continuer=readString();
                repos(nav,event,bonus,malus,1,param);
            }
        }
    }
    void verifNiveaux(Navette nav){
        if(nav.nivElec>=nav.nivElecMAX){
            nav.nivElec=nav.nivElecMAX;
        }
        if(nav.nivOxy>=nav.nivOxyMAX){
            nav.nivOxy=nav.nivOxyMAX;
        }
        if(nav.nivTemp>=nav.nivTempMAX){
            nav.nivTemp=nav.nivTempMAX;
        }
        if(nav.fatigue>100){
            nav.fatigue=100;
        }else if(nav.fatigue<0){
            nav.fatigue=0;
        }
    }

    boolean[][] initialiserBonusMalus(Param param){// les event[0][i] représentent les bonus, les event[1][i] les malus
        boolean[][] event = new boolean[2][param.duréeJeu];
        double p;
        for(int t=0; t<param.duréeJeu; t=t+1){
            p=random();
            
            if(p<=param.probaBonus){
                event[0][t]=true;
                event[1][t]=false;
            }else if((p<=param.probaMalus+param.probaBonus)&&(p>param.probaBonus)){ //on choisit qu'on ne peut avoir d'évèneent positif etnégatif en même temps, et qu'un évènement négatif ne peut arriver que s'il n'y a pas d'évènement positif.
                event[1][t]=true;
                event[0][t]=false;
            }
        }
        return event;
    }

    String conséquenceBonusMalus(BonusMalus BoM, Navette nav){
        double bonus=random()*(length(BoM.casPossibles)-1);
        int bonusChoisi=(int)(bonus);
        nav.nivElec+=(BoM.impactMax[bonusChoisi][0]);
        nav.nivOxy+=(BoM.impactMax[bonusChoisi][1]);
        nav.nivTemp+=(BoM.impactMax[bonusChoisi][2]);
        nav.perteElec+=(BoM.perteMax[bonusChoisi][0]);
        nav.perteOxy+=(BoM.perteMax[bonusChoisi][1]);
        nav.perteTemp+=(BoM.perteMax[bonusChoisi][2]);
        return BoM.casPossibles[bonusChoisi];
    }
    
    String perteRepos(Navette nav){
        nav.fatigue-=10;
        nav.nivElec-=nav.perteElec;
        nav.nivOxy-=nav.perteOxy;
        nav.nivTemp-=nav.perteTemp;
        return " Heure "+nav.logH+" : Vous avez perdu "+COLOR_YELLOW+nav.perteElec+ANSI_RESET+" unités d'électricité, "+COLOR_BLUE+nav.perteOxy+ANSI_RESET+" unités d'oxygène et "+COLOR_RED+nav.perteTemp+ANSI_RESET+" unités de température.";
    }
    
    void repos(Navette nav, boolean[][] event, BonusMalus B, BonusMalus M, int tempsRepos,Param param){ //Catégorie BonusMalus charge un tableau avec les différents évenements possinbbles
        print(Remplissage("Rapport des incidents : ",param,0));
        String nouvelles="";
        int hDebutRepos=nav.logH;
        while((nav.logH<hDebutRepos+tempsRepos)&&!VaisseauDetruit(nav)&&(nav.logH<param.duréeJeu)){
            if(event[0][nav.logH]){
                nouvelles+=" "+ANSI_GREEN+"Bonne nouvelle ! : "+ANSI_RESET+conséquenceBonusMalus(B,nav)+"\n ";
            }else if(event[1][nav.logH]){       
                nouvelles+=" "+ANSI_RED+"Mauvaise nouvelle ! : "+ANSI_RESET+conséquenceBonusMalus(M,nav)+"\n ";
            }else{
                nouvelles="Rien de nouveau"+"\n ";
            }  
            print(Remplissage(perteRepos(nav),param,0));
            afficherBulle(nouvelles,param,0);
            nouvelles="";
            verifNiveaux(nav);
            nav.logH++;
        }
        if(nav.logH>=param.duréeJeu){
            gameOver(nav);
        }
        
    }
    
    boolean VaisseauDetruit(Navette nav){
        return ((nav.nivOxy<=0)||(nav.nivElec <=0)||(nav.nivTemp <=0));
    }
    void gameOver(Navette vaisseau){
        if(VaisseauDetruit(vaisseau)){
            afficherBulle("Vous n'avez pas survécu, ce voyage fut le dernier voyage de"+vaisseau.nom,param,0);
        }else{
            //Victoire
            afficherBulle(vaisseau.nom+" a survécu à ce voyage, vous avez pu être secouru",param,0);
        }
        String finPartie=readString();
        sceneActuelle=Scene.MENU;
    }

    /////////////////////////////////////////////
    ///////////////////SCENES////////////////////
    /////////////////////////////////////////////

    void sceneMenuPrincipal(){
        int option = 0;
        
        String titre = STYLE_BOLD + COLOR_ORANGE +
        "   __             __    ____        ______ __         _   __       _     __ \n" +
        "  / /  ___   ___ / /_  /  _/___    /_  __// /  ___   | | / /___   (_)___/ /\n" +
        " / /__/ _ \\ (_-</ __/ _/ / / _ \\    / /  / _ \\/ -_)  | |/ // _ \\ / // _  /\n" +
        "/____/\\___//___/\\__/ /___//_//_/   /_/  /_//_/\\__/   |___/ \\___//_/ \\_,_/\n\n" + ANSI_RESET;
        String optionsMenu = "1. Jouer\n 2. Paramètres\n 3. Quitter\n";
        do{
            println(CLEAR);
            println(titre);
            if(option != 0){
                println(COLOR_RED + "\n Option Invalide\n " + ANSI_RESET);
            } else{
                println(STYLE_UNDERLINE + COLOR_GOLD + "\n Choisissez une option\n " + ANSI_RESET);
            }
            afficherBulle(optionsMenu, param,0);
            option = readInt();
         }while(!(estChoixPossible(1,3,option)));

        //On change de scène selon la saisie
        if(option == 1){
            sceneActuelle = Scene.INTRODUCTION;
        } else if(option == 2){
            sceneActuelle = Scene.PARAMETRES;
        } else if(option == 3){
            exec = false;
        }    
        
    }

    void sceneParametres(){
        // Affichage en titre "paramètres"
        do{
            println(STYLE_UNDERLINE+COLOR_GOLD+"Paramètres : "+ANSI_RESET+'\n');
            println("Veuillez choisir ce que vous voulez modifier\n1.Modifier difficulté.\n2.Modifier affichage.\n0.Quitter.");
            int saisie;
            do{
                saisie=readInt();

            }while(!estChoixPossible(0,2,saisie));
            println(CLEAR);
            if(saisie==1){
                setDifficulty(param);
            }else if(saisie==2){
                setAffichage(param);
            }else if(saisie==0){
                sceneActuelle=Scene.MENU;
            }
        }while(sceneActuelle==Scene.PARAMETRES);
        
        }

        // Choix de ce que l'on souhaite configurer (1. Difficulté - 2. Taille des bulles)
        // Saisie
        // ...
    
        
    void sceneIntroduction(){
        
        // paragraphes de l'introduction avec des images ASCII
        // saisie pour passer un paragraphe
        sceneActuelle = Scene.JEU;// après que tout les paragraphes de l'info soient passés, le joueur passe à la scéne "JEU"
    }

    void sceneJeu(){
        Navette vaisseau=newNavette(param);
        print("À bord de quel vaisseau avez vous décollé ? :");
        vaisseau.nom=readString();
        int heure=1;
        int objectif= param.duréeJeu;
        boolean[][] Bonusmalus=initialiserBonusMalus(param);
        initBonusMalus();
        boolean enjeu=true;
        while(enjeu){
            afficherNiveaux(vaisseau,param);
            afficherActions(vaisseau,param,Bonusmalus,bonus,malus);
            enjeu=(!VaisseauDetruit(vaisseau)&&(vaisseau.logH<=objectif));
        // Afficher heure - description (journal de bord)+Afficher les jauges des ressources+Actions
            // 
            // 
            // Saisie utilisateur
            // Clear
            println("FIN DE BOUCLE");
        }
        gameOver(vaisseau);
        /* game over */
    }
    
    void algorithm(){
        initQuestions();

        while(exec){
            if(sceneActuelle == Scene.MENU){
                sceneMenuPrincipal();
            } else if(sceneActuelle == Scene.PARAMETRES){
                sceneParametres();
            } else if(sceneActuelle == Scene.INTRODUCTION){
                sceneIntroduction();
            } else if(sceneActuelle == Scene.JEU){
                sceneJeu();
            }
        }
        // sortie de la boucle -> on quitte le jeu
        // sauvegarder les parametres si on a le temps?
    }
} 
