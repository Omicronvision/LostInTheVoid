class Quiz{
    String[][] quiz;
    int questionPrecedente; //permet de stocker l'indice de la question en fin de question, cela permettra d'y faire référence en dehors du moment où la question est posée.
    boolean[] questionsFaites; // un tableau de boolean qui correspond aux questions répondues. une fois une question bien répondue, on tourne le booléen correspondant à la question en true, et tant qu'il est en true, cette question ne reviendra pas
    int compteurFait;//compte le nombre de questions faites. une fois une question bien répondue, incrémenté de 1. Une fois toutes les questions faites (compteurFait = nbr questions), lance la réinitialisation du tableau de booléens. on aurait pu faire une fonction qui vérifiait l'état du tableau avec un while tab[i]==false mais on pense que utiliser un compteur économisera un peu de calcul. 
}