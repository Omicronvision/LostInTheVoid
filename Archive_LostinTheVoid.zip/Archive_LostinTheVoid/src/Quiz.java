class Quiz{
    String[][] quiz;
    int questionPrecedente; //pourquoi pas stocker l'indice de la question en fin de question, pour éviter toute répétion de la même question 2 fois de suite.
}