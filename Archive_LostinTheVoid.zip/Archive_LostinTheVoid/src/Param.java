class Param{
    int difficulte;
    int nivOxyInitial;
    int nivElecInitial;
    int nivTempInitial;
    int degats;
    int tailleEcran;
    int nTours;
    double probaMalus;
    double probaBonus;
    int duréeJeu;
    int perteInit;
}