class Param{
    String difficulte;
    int nivInit;
    int degats;
    int tailleEcran;
    double probaMalus;
    double probaBonus;
    int duréeJeu;
    int perteInit;
}